<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content-vw">
 *
 * @package VW Automobile Lite
 */

?><!DOCTYPE html>

<html <?php language_attributes(); ?>>

<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>">
  <meta name="viewport" content="width=device-width">
  <link rel="profile" href="http://gmpg.org/xfn/11">
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
  <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
  <div class="toggle"><a class="toggleMenu" href="#"><?php esc_html_e('Menu','vw-automobile-lite'); ?></a></div>
  
  <div id="header">
    <div class="container">
      <div class="col-md-3 col-sm-3 col-xs-12">
        <div class="logo wow bounceInDown">        
          <?php if( has_custom_logo() ){ vw_automobile_lite_the_custom_logo();
             }else{ ?>
            <h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
            <?php $description = get_bloginfo( 'description', 'display' );
            if ( $description || is_customize_preview() ) : ?> 
              <p class="site-description"><?php echo esc_html($description); ?></p>       
          <?php endif; }?>
        </div><?php /** logo **/ ?>
      </div>
      <div class="col-md-9 col-xs-12 col-sm-9">
        <div class="top-contact col-md-3 col-xs-12 col-sm-4">
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_contact','' ) ) != '') { ?>
            <span class="call"><i class="fa fa-phone" aria-hidden="true"></i><?php echo esc_html( get_theme_mod('vw_automobile_lite_contact',__('(518) 356-5373','vw-automobile-lite') )); ?></span>
           <?php } ?>
        </div>   
        <div class="top-contact col-md-3 col-xs-12 col-sm-4">
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_email','' ) ) != '') { ?>
            <span class="email_corporate"><i class="fa fa-envelope" aria-hidden="true"></i><?php echo esc_html( get_theme_mod('vw_automobile_lite_email',__('support@vwthemes.com','vw-automobile-lite')) ); ?></span>
          <?php } ?>
        </div>
        <div class="social-media col-md-6 col-sm-4 col-xs-12">
           <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_youtube_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_youtube_url','' ) ); ?>"><i class="fa fa-youtube" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_facebook_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_facebook_url','' ) ); ?>"><i class="fa fa-facebook" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_twitter_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_twitter_url','' ) ); ?>"><i class="fa fa-twitter" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_rss_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_rss_url','' ) ); ?>"><i class="fa fa-rss" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_insta_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_insta_url','' ) ); ?>"><i class="fa fa-instagram" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_google_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_google_url','' ) ); ?>"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
          <?php } ?>
          <?php if(esc_url( get_theme_mod( 'vw_automobile_lite_pint_url','' ) ) != '') { ?>
            <a href="<?php echo esc_url( get_theme_mod( 'vw_automobile_lite_pint_url','' ) ); ?>"><i class="fa fa-pinterest-p" aria-hidden="true"></i></a>
          <?php } ?>
        </div>
        <div class="menubox">
          <div class="nav">
  		    <?php wp_nav_menu( array('theme_location'  => 'primary') ); ?>
          </div><?php /** nav  **/ ?>
        </div><?php /** menubox **/ ?>
        <div class="clearfix"></div>
      </div>
    </div>
  </div><?php /** header **/ ?>