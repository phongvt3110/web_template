		<div class="entry-meta">
			<?php karuna_posted_on(); ?>
		</div><!-- .entry-meta -->