	<footer class="entry-footer">
		<?php karuna_entry_footer(); ?>
	</footer><!-- .entry-footer -->