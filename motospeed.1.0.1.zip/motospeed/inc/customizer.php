<?php

if ( ! function_exists( 'motospeed_customize_register' ) ) :
	/**
	 * Add postMessage support for site title and description for the Theme Customizer.
	 *
	 */
	function motospeed_customize_register( $wp_customize ) {

		/**
		 * Add Footer Section
		 */
		$wp_customize->add_section(
			'motospeed_footer_section',
			array(
				'title'       => __( 'Footer', 'motospeed' ),
				'capability'  => 'edit_theme_options',
			)
		);
		
		// Add Footer Copyright Text
		$wp_customize->add_setting(
			'motospeed_footer_copyright',
			array(
			    'default'           => '',
			    'sanitize_callback' => 'sanitize_text_field',
			)
		);

		$wp_customize->add_control( new WP_Customize_Control( $wp_customize, 'motospeed_footer_copyright',
	        array(
	            'label'          => __( 'Copyright Text', 'motospeed' ),
	            'section'        => 'motospeed_footer_section',
	            'settings'       => 'motospeed_footer_copyright',
	            'type'           => 'text',
	            )
	        )
		);
	}
endif; // motospeed_customize_register
add_action( 'customize_register', 'motospeed_customize_register' );
