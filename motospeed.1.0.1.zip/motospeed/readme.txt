=== Theme Name ===
Contributors: customizablethemes
Tags: blog, entertainment, two-columns, right-sidebar, custom-logo, custom-background, custom-header, custom-menu, threaded-comments, translation-ready, sticky-post, theme-options, footer-widgets
Requires at least: 4.7.0
Tested up to: 4.8.2
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

MotoSpeed WordPress Theme, Copyright 2017 CustomizableThemes.com

== Description ==

MotoSpeed is fully Responsive Moto WordPress Theme. Features: Custom Logo, Custom Background, Footer copyright text customizations, Widget Areas: Sidebar, 3 Footer Columns, Translation-Ready and much more.

== Changelog ==

= 1.0.1 =
* update readme.txt file
* css bug fixes

= 1.0.0 =
* initial release

== Resources ==
*
* assets/css/font-awesome.css © FontAwesome, MIT
* assets/fonts/FontAwesome.otf © FontAwesome, MIT
* assets/fonts/fontawesome-webfont.eot © FontAwesome, MIT
* assets/fonts/fontawesome-webfont.svg © FontAwesome, MIT
* assets/fonts/fontawesome-webfont.ttf © FontAwesome, MIT
* assets/fonts/fontawesome-webfont.woff © FontAwesome, MIT
* assets/fonts/fontawesome-webfont.woff2 © FontAwesome, MIT
*
* Overlock (default theme font), © Google Fonts, GNU Version 2
*
* screenshot.png (Post Image), © Alexas_Fotos
* image source, https://pixabay.com/en/mini-cooper-auto-model-vehicle-783697/, CC0
*
* inc/customize-pro/class-customize.php, © Justin Tadlock (justintadlock), GNU Version 2
* inc/customize-pro/customize-controls.css, © Justin Tadlock (justintadlock), GNU Version 2
* inc/customize-pro/customize-controls.js, © Justin Tadlock (justintadlock), GNU Version 2
