<?php
/**
 * Displays header media
 *
 * @package WordPress
 * @subpackage EggNews
 * @since 1.3.3
 * @version 1.3.3
 */

?>
<div class="custom-header">

		<div class="custom-header-media">
			<?php the_custom_header_markup(); ?>
		</div>

</div><!-- .custom-header -->
