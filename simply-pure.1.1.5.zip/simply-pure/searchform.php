<form class="pure-form searchform" action="<?php echo esc_url(home_url()); ?>" method="get">
    <input type="search" name="s" class="searchbox" placeholder="<?php _e('Search...', 'simply-pure')?>">
    <button type="submit" class="searchbutton"><?php _e('Go', 'simply-pure');?></button>
</form>