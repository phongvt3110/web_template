<div class="navigation">
	<div class="alignleft"><?php previous_posts_link('&laquo; '.__('Previous Entries','simply-pure'),'') ?></div>
	<div class="alignright"><?php next_posts_link(__('Next Entries','simply-pure').' &raquo;','') ?></div>
</div>