<div id="sidebar">
<?php if ( ! dynamic_sidebar( 'Sidebar' )) : ?>
<?php endif; ?>
</div></div>