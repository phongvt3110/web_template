Seos Business WordPress Theme, Copyright 2015 Tsvetomir Tsvetanov
Seos Business is distributed under the terms of the GNU GPL2

=== Seos Business ===
Theme Name: Seos Business
Description: Seos Business is the 2015 theme, dark multi-purpose theme with a responsive 2 column layout. Seos Business is 100% responsive built with HTML5 & CSS3, it’s SEO friendly. The theme is tested for speed there are no mistakes in the HTML code. We designed it using a mobile-first approach, meaning your content takes center-stage, regardless of whether your visitors arrive by smartphone, tablet, laptop, or desktop computer.  Customizer: background color, header color, nav color, hover color, header image, background image, social media buttons, upload logo. To learn more about the theme please see theme homepage.
Author: SEOS - Tsvetomir Tsvetanov
Author URI: http://seosthemes.com/
Theme URI: http://seosthemes.com/seos-business/
Tags: black, dark, two-columns, left-sidebar, right-sidebar, responsive-layout, custom-menu, custom-background, custom-colors, custom-header, custom-menu, featured-images, threaded-comments, photoblogging
Version: 1.24
License: GNU General Public License 2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Text Domain: seosbusiness

== Description ==
Seos Business - is dark multi-purpose theme with a responsive 2 column layout. We designed it using a mobile-first approach, meaning your content takes center-stage, regardless of whether your visitors arrive by smartphone, tablet, laptop, or desktop computer. Seos Business - 2015.

* Responsive Layout
* Custom Colors
* Custom Header
* Social Links
* The GPL v2.0 or later license. :) Use it to make something cool.

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= How do I add the Social Links to the header =

Seos Business allows you display links to your social media profiles, like Twitter and Facebook, with icons.

1. In your admin panel, go to Appearance -> Customize.
2. Now you will see the Customizer and a tab called 'Social Media'. Click this tab.

Social networks that aren't currently supported will be indicated by a generic share icon.

####################### Licenses #######################
 Seos Business WordPress Theme bundles the following third-party resources:

 * Images - https://www.pexels.com/search/new%20york/ - CC0 1.0 License
 * Fonts - https://www.google.com/fonts/specimen/Oswald - SIL Open Font License, 1.1
 
 Unless otherwise specified, all the theme files, scripts and images
 are licensed under GNU General Public License version 2.