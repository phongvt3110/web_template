		<aside>

			<ul>

				<?php if ( ! dynamic_sidebar('right') ) : ?><?php endif; ?>

			</ul>

		</aside>