"viralline a gracefull WordPress Theme" By ThemeHunk.

== Theme: viralline ==

* By ThemeHunk, http://themehunk.com/

== Theme License & Copyright ==
viralline Theme is distributed under the terms of the GNU GPL
viralline Theme - Copyright 2014 viralline Theme, themehunk.com

License for images:

1. Image Name: post-main-img.jpeg
Resource link: https://www.pexels.com/photo/man-in-black-in-front-of-blue-bus-during-daytime-66363/
Licensed under the CCO license.
License link : https://www.pexels.com/photo-license/


== classie.js
Licensed under the MIT license
License URL for CSS : http://opensource.org/licenses/mit-license.html

== owl.carousel.js
Licensed under the MIT license
License URL for CSS : http://opensource.org/licenses/mit-license.html

== Lato Font ==
License: SIL OFL 1.1
License URL: http://scripts.sil.org/OFL

== Open Sans Font ==
License: SIL OFL 1.1
License URL: http://scripts.sil.org/OFL

== Playfair Display Font ==
License: SIL OFL 1.1
License URL: http://scripts.sil.org/OFL

== FontAwesome License ==
License: SIL OFL 1.1
License URl for Font : http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&id=OFL

== Font Awesome CSS license ==
License: MIT License
License URL for CSS : http://opensource.org/licenses/mit-license.html

==  Other Licenses ==
See headers of files for further details.
	
== Theme License & Copyright ==
GlowLine is distributed under the terms of the GNU GPL
GlowLine -Copyright 2014 GlowLine, ThemeHunk.com
License : GPL License
License URL: https://www.gnu.org/licenses/gpl-3.0.en.html

custom.js, mobile-menu.js is distributed under the terms of the GNU GPL
License For js
    All js files are GPL Compatible.
    See headers of JS files for further details.

Once again, thank you so much for trying the GlowLine WordPress Theme. As we said at the beginning, we will be glad to help you. If you have any questions related to this theme then do let us know & we will try our best to assist. If you have any general questions related to the themes on ThemeHunk, we would recommend you to visit the ThemeHunk Support Forum and ask your queries there.