/*
 * Specia theme admin script
 */

jQuery(function ( $ ) {
    'use strict';

    $( '#tabs' ).tabs();
});
